// ============================================================
// PHOTO DATA
//
// File ini KHUSUS untuk:
// - foto
// - title foto
// - description foto
//
// KODE:
// C = Coffee Spot
// K = Cashier
// E = Expenses
// ============================================================


// ============================================================
// IMAGE IMPORTS
// ============================================================

const coffeeSpotImages = import.meta.glob(
  "../assets/coffeespot/*.png",
  {
    eager: true,
    query: "?url",
    import: "default",
  }
);

const cashierImages = import.meta.glob(
  "../assets/cashier/*.png",
  {
    eager: true,
    query: "?url",
    import: "default",
  }
);

const expensesImages = import.meta.glob(
  "../assets/expenses/*.png",
  {
    eager: true,
    query: "?url",
    import: "default",
  }
);


// ============================================================
// HELPER
// ============================================================

const getImageByName = (images, fileName) => {
  const entry = Object.entries(images).find(
    ([path]) => path.endsWith(`/${fileName}`)
  );

  return entry?.[1] || null;
};


// ============================================================
// PHOTO DATABASE
// ============================================================

export const photoData = {

  // ==========================================================
  // COFFEE SPOT
  // ==========================================================

  C1: {
    image: getImageByName(
      coffeeSpotImages,
      "coffeespot1.png"
    ),

    title: "DISCOVERY",

    description:
      "The main experience introduces users to curated coffee spots through a clean and visually focused interface.",
  },


  C2: {
    image: getImageByName(
      coffeeSpotImages,
      "coffeespot2.png"
    ),

    title: "COFFEE EXPLORATION",

    description:
      "Users can explore available coffee spots through a structured interface designed around discovery and visual hierarchy.",
  },


  C3: {
    image: getImageByName(
      coffeeSpotImages,
      "coffeespot3.png"
    ),

    title: "LOCATION DETAIL",

    description:
      "Detailed information is presented in a focused layout, making important coffee spot information easy to explore.",
  },


  C4: {
    image: getImageByName(
      coffeeSpotImages,
      "coffeespot4.png"
    ),

    title: "VISUAL SYSTEM",

    description:
      "Custom UI elements and gradient treatments create a distinctive visual identity across the experience.",
  },


  C5: {
    image: getImageByName(
      coffeeSpotImages,
      "coffeespot5.png"
    ),

    title: "RESPONSIVE EXPERIENCE",

    description:
      "The interface adapts across screen sizes while maintaining the same visual structure and interaction quality.",
  },


  C6: {
    image: getImageByName(
      coffeeSpotImages,
      "coffeespot6.png"
    ),

    title: "COFFEE DETAILS",

    description:
      "Important coffee spot information is presented through a focused interface that keeps the experience clear and easy to navigate.",
  },


  C7: {
    image: getImageByName(
      coffeeSpotImages,
      "coffeespot7.png"
    ),

    title: "DISCOVERY FLOW",

    description:
      "The interface guides users through the discovery process with clear visual hierarchy and intuitive navigation.",
  },


  C8: {
    image: getImageByName(
      coffeeSpotImages,
      "coffeespot8.png"
    ),

    title: "INTERACTION",

    description:
      "Interactive elements are structured to create a smooth and engaging browsing experience.",
  },


  C9: {
    image: getImageByName(
      coffeeSpotImages,
      "coffeespot9.png"
    ),

    title: "CONTENT SYSTEM",

    description:
      "Content is organized into a consistent visual system that keeps information easy to understand.",
  },


  C10: {
    image: getImageByName(
      coffeeSpotImages,
      "coffeespot10.png"
    ),

    title: "USER EXPERIENCE",

    description:
      "The experience combines visual clarity with intuitive interactions to make exploration feel natural.",
  },


  C11: {
    image: getImageByName(
      coffeeSpotImages,
      "coffeespot11.png"
    ),

    title: "MOBILE EXPERIENCE",

    description:
      "The interface is adapted for smaller screens while preserving the core visual identity and usability.",
  },


  C12: {
    image: getImageByName(
      coffeeSpotImages,
      "coffeespot12.png"
    ),

    title: "INTERFACE DETAILS",

    description:
      "Small interface details help strengthen the overall visual language and interaction quality.",
  },


  C13: {
    image: getImageByName(
      coffeeSpotImages,
      "coffeespot13.png"
    ),

    title: "FINAL INTERFACE",

    description:
      "The final interface brings together the visual system, content structure, and interaction patterns into one cohesive experience.",
  },


  C14: {
    image: getImageByName(
      coffeeSpotImages,
      "coffeespot14.png"
    ),

    title: "FINAL EXPERIENCE",

    description:
      "A complete view of the final digital experience, combining functionality, visual identity, and responsive interaction.",
  },


  // ==========================================================
  // CASHIER
  // ==========================================================

  K1: {
    image: getImageByName(
      cashierImages,
      "project-02.png"
    ),

    title: "CASHIER SYSTEM",

    description:
      "A fast and responsive cashier interface designed for efficient daily transaction operations.",
  },


  // ==========================================================
  // EXPENSES
  // ==========================================================

  E1: {
    image: getImageByName(
      expensesImages,
      "project-03.png"
    ),

    title: "EXPENSES TRACKER",

    description:
      "A financial tracking interface designed to help users manage and monitor their daily financial activity.",
  },

};